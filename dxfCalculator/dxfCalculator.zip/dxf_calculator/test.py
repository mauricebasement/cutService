f = open("circle5.dxf")
lines = f.readlines()
print lines
